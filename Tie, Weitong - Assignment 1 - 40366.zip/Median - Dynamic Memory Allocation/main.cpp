#include <iostream>
#include<iomanip>

using namespace std;

int *getData(int &);       //Return the array size and the array
void prntDat(int *,int);   //Print the integer array
float *median(int *,int);  //Fill the median Array with the Float array size, the median, and the integer array data
void prntMed(float *,int); //Print the median Array

int main(){
    //your code here
    int size = 0;
    int *numbers = getData(size);

    float *m = median(numbers, size);

    prntDat(numbers, size);
    prntMed(m, size);
    
    return 0;
}
int* getData(int& size){
    int r;
    cin>>r;
    int *num = new int[r];
    for(int i=0; i<r; ++i){
        cin>>num[i];
    }
    size=r;
    return num;
}

float *median(int* numbers, int size){
    float *arr = new float[size+2];
    for(int i=2;i<size+2;++i)
    arr[i] = 1.0*numbers[i-2];
    arr[0] = size+2;
    if(size % 2 != 0){
        float median = *(numbers + (size/2) );
        arr[1] = median;
    }
    else{
        int index1 = (size / 2) -1;
        int index2 = size / 2;
        float median = ( *(numbers + index1) + *(numbers +index2) )/ 2.0;
        arr[1] = median;
    }
    return arr;
}
void prntDat(int *arr,int n){
    for(int i=0; i<n; ++i){
        if(i>0){
            cout<<" ";
        }
        cout<<arr[i];
    }
    cout<<endl;
}
void prntMed (float *arr, int n ){
    cout<<arr[0];
    for(int i=1; i<n+2; ++i){
        cout<<fixed<<setprecision(2)<<" "<<arr[i];
    }
}