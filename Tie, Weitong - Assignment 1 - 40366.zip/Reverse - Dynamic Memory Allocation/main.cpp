#include<iostream>
using namespace std;

int *getData(int size){
    int *arr = new int [size];
    for(int i=0;i<size;i++){
        cin>>arr[i];
    }
    
    return arr;
}

int *sort(int *arr,int size) {
    int s=size;
    for(int i=s-1;i>=0;i--){
        for(int r=0;r<i;r++){
            if(arr[r]>arr[r+1]){
                int temp=arr[r];
                arr[r]=arr[r+1];
                arr[r+1]=temp;
            }
       }
   }
}

int reverse(int *arr,int size){
    int n=size;
    for(int i=n-1;i>=0;i--){
        for(int j=0;j<i;j++){
            if(arr[j]<arr[j+1]){
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
}
void prntDat(const int *arr,int size){
    for(int i=0;i<size;i++){
        if(i>0){
            cout<<" ";
        }
        cout<<arr[i];
    }
}

int main(){
    //your code here
    int size;
    cin>>size;
    int *a = getData(size);
    sort(a,size);
    prntDat(a,size);
    reverse(a,size);
    cout<<"\n";
    prntDat(a,size);
   
    return 0;
}