#include <iostream>

using namespace std;

int *getData(int &);           //Return the array size and the array from the inputs
int *sumAry(const int *,int);  //Return the array with successive sums
void prntAry(const int *,int); //Print the array

int main(){
    //your code here
    int n;
    int *array=getData(n);
    int *sum=sumAry(array, n);
    
    prntAry(array, n);
    cout<<endl;
    prntAry(sum, n);

    return 0;
}

int *getData(int &n){
    cin>>n;
    int *arr=new int[n];

    for (int i=0; i<n; i++){
        cin>>arr[i];
    }
    return arr;

}

int *sumAry(const int *arr, int n){
    int *sum=new int[n];
    sum[0]=arr[0];

    for (int i=1; i<n; i++){
        sum[i]=sum[i-1]+arr[i];
    }
    return sum;
}

void prntAry(const int *array, int n){
    for (int i=0; i<n; i++){
        if(i>0){
            cout<<" ";
        }
        cout<<array[i];
    }
}
