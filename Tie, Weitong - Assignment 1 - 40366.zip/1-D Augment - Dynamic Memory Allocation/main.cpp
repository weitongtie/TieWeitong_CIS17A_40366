#include <iostream>

using namespace std;

int *getData(int &);           //Read the array
int *augment(const int *,int); //Augment and copy the original array
void prntAry(const int *,int); //Print the array

int main(){
    //your code here
    int n;
    cin>>n;
    int *arr=getData(n);
    prntAry(arr, n);
    cout<<endl;
    arr=augment(arr, n);
    prntAry(arr, n+1);

    return 0;
}

int *getData(int &n){
    int *arr=new int[n];

    for(int i=0; i<n; i++){
        cin>>arr[i];
    }
return arr;
}

int *augment(const int *arr, int n) {
    int *r = new int[n+1];
    r[0] = 0;

    for (int i = 0; i<n; i++){
        r[i+1]=arr[i];
    }

return r;
}

void prntAry(const int *arr, int n){
    for (int i=0; i<n; i++) {
        if(i>0){
            cout<<" ";
        }
        cout<<arr[i];
    }
}