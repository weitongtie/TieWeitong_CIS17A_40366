#include <iostream>
#include <random>

using namespace std;

int **getData(int &,int &);              //Return the 2-D array and its size.
void prntDat(const int* const *,int,int);//Print the 2-D Array
void destroy(int **,int,int);            //Deallocate memory
int sum(const int * const *, int,int);   //Return the Sum

int main(){
    //your code here
    int **array, n, m;
    
    array=getData(n, m);
    prntDat(array, n, m);
    cout<<sum(array, n, m);
    destroy(array, n, m);
    
    return 0;
}

int **getData(int &n, int &m){
    cin>>n>>m;
    int **array=new int *[n];

    for (int i=0; i<n; i++){
        array[i]=new int[m];
        
        for (int j=0; j<m; j++){
            cin>>array[i][j];
        }
    }
    return array;
}

void prntDat(const int *const *array, int n, int m){
    
    for (int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            if(j>0){
                cout<<" ";
            }
            cout<<array[i][j];
        }
        cout << endl;
    }
}
void destroy(int **arr, int n, int m){
    for (int i=0; i<n; i++){
        delete[] arr[i];
    }
    delete arr;
}

int sum(const int *const *arr, int n, int m){
    int sum=0;

    for (int i=0; i<n; i++){
        for (int j=0; j<m; j++){
            sum+=arr[i][j];
        }
    }
    return sum;
}