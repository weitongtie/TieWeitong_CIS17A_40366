#include <iostream>

using namespace std;

int **getData(int &,int &);                  //Get the Matrix Data
void printDat(const int * const *,int,int);  //Print the Matrix
int **augment(const int * const *,int,int);  //Augment the original array
void destroy(int **,int);                    //Destroy the Matrix, i.e., reallocate memory

int main() {
   //your code here
    int row,col;
    int **n;
  
    n=getData(row,col);   
    printDat(n,row,col);
    cout<<endl;
    ++row;
    ++col;
    n=augment(n,row,col);
    printDat(n,row,col);
    destroy(n,row);
  
   return 0;
}

int **getData(int &row,int &col){
    cin>>row>>col;
   
    int** arr = new int*[row];
    for(int i=0; i<row; ++i){
        arr[i] = new int[col];
    }
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
           cin>>arr[i][j];
        }
    }
    return arr;
}

void printDat(const int * const *n,int row,int col){
   for(int i=0;i<row;i++)
    {
       for(int j=0;j<col;j++)
        {
            if(j>0){
               cout<<" ";
            }
            cout<<n[i][j];
        }
        if(i<row-1){
            cout<<endl;
        }
    }
}

int **augment(const int * const *n,int row,int col){
    int** arr=new int*[row];
    for(int i=0; i<row; ++i){
        arr[i] = new int[col];
    }
    
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            if(i==0){
                arr[i][j]=0;
            }
            else if(j==0){
                arr[i][j]=0;                  
            }
            else{
                arr[i][j]=n[i-1][j-1];
            }
        }
    }
    return arr;
}

void destroy(int **n,int size){
    for(int i=0; i<size; i++){
        delete[] n[i];
    }
}